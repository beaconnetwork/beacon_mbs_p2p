# beacon_mbs_p2p
A mqtt message broker run over peer_to_peer overlay network.

## [Docker Image Package]
Release v2020.03.20 https://github.com/TheSmallBoat/beacon_mbs_p2p/packages/251191

## [Related Documents]
https://github.com/TheSmallBoat/beacon_docs/tree/master/mqtt_p2p_network_test_demo_20_03
